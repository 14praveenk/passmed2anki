# Passmedicine → Anki

A small cross-browser extension that reveals an **Add to Anki** button on Passmedicine once the answer panel is visible. Clicking the button sends the current question, options, and revealed answer to Anki through the [AnkiConnect](https://foosoft.net/projects/anki-connect/) API.

## Single purpose

This extension has one purpose: **convert a Passmedicine question you’ve answered into an Anki note when you click “Add to Anki”.**

## Features

- Watches Passmedicine question pages and injects a button only after answers are shown.
- Captures the question stem, visible answer choices, and the revealed answer/explanation.
- Sends notes to Anki with your preferred deck, model, and tags via AnkiConnect.
- Works in Chromium browsers (Chrome, Edge, Brave, Vivaldi) and Firefox (Manifest V3).
- Options page to configure deck/model/tag defaults.

## Prerequisites

1. Install Anki desktop (2.1.55+ recommended) and keep it running.
2. Install the AnkiConnect add-on (code `2055492159`) inside Anki and restart it.
3. Ensure the deck and note type you plan to use already exist in Anki.

## Installation

### Chrome / Edge / Other Chromium

1. `chrome://extensions` → toggle **Developer mode**.
2. Click **Load unpacked** and select this project folder.
3. Open `chrome-extension://…/options.html` (or use the *Details → Extension options* link) to set the deck/model/tags.
4. Browse Passmedicine, reveal an answer, and press **Add to Anki**.

### Firefox

1. Visit `about:config` and ensure `xpinstall.signatures.required` is `false` (for temporary testing) or sign the add-on for long-term use.
2. Go to `about:debugging#/runtime/this-firefox` → **Load Temporary Add-on** → select this folder.
3. Open the options page and configure your deck/model/tags.
4. Navigate to Passmedicine, reveal the answer, then click **Add to Anki**.

> Temporary add-ons disappear after a browser restart. For permanent installation, package the folder as a zip and sign/upload via [Firefox Add-ons Developer Hub](https://addons.mozilla.org/en-US/developers/).

## Customization & Notes

- You can edit the selector lists in `contentScript.js` if Passmedicine changes its markup. Add/remove CSS selectors until `findVisibleElement` locates the right nodes.
- The front field contains the question stem plus visible answer list; the back field contains the revealed answer/explanation.
- Tags entered in the options page are merged with a built-in `passmedicine` tag.
- Request failures (e.g., Anki not running) are surfaced through a toast UI in the bottom-right corner.

## Packaging

To publish, zip the folder contents (without `.zip` nesting) and upload to the Chrome Web Store dashboard and/or Firefox Developer Hub. Both stores accept Manifest V3 packages.

## Troubleshooting

- **Button never appears**: ensure the answer panel is actually revealed— the script checks for visible answer containers. Review the console for logged selector misses.
- **Enable debug logs**: run `window.postMessage({ __passmed2anki: { debug: true } }, "*")` in the page console, then reveal the answer and look for `[Passmed2Anki]` logs. Disable with `window.postMessage({ __passmed2anki: { debug: false } }, "*")`.
- **No debug output at all**: confirm the extension is loaded/enabled for the Passmedicine domain and hard-refresh the page. The content script only runs on `*.passmedicine.com` URLs.
- **Failed to reach AnkiConnect**: make sure Anki is open, AnkiConnect is installed, and no firewall blocks `http://127.0.0.1:8765`.
- **CORS error in console**: the extension sends AnkiConnect requests from the extension background worker (not the webpage) specifically to avoid browser CORS restrictions. If you still see CORS errors, reload the extension so `background.js` is active.
- **Deck/model errors**: confirm the deck and model names entered in the options page match Anki exactly (case sensitive).
#   p a s s m e d 2 a n k i  
 